import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter as Router, Route, Link, Switch } from "react-router-dom";
import CreateEmployee from "./components/employee/CreateEmployee";
import ListEmployee from "./components/employee/ListEmployee";
import ModifyEmployee from "./components/employee/ModifyEmployee";

function App() {
  return (
    <div className="App">
      <Router>
        <div className="container">
          <nav className="btn btn-warning navbar navbar-expand-lg navheader">
            <div className="collapse navbar-collapse">
              <ul className="navbar-nav mr-auto">
                <li className="nav-item">
                  <Link to={"/Create"} className="nav-link">
                    Create Employee
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to={"/List"} className="nav-link">
                    List Employees
                  </Link>
                </li>
              </ul>
            </div>
          </nav>
          <br />
          <Switch>
            <Route exact path="/Create" component={CreateEmployee} />
            <Route exact path="/modify/:id" component={ModifyEmployee} />
            <Route exact path="/List" component={ListEmployee} />
          </Switch>
        </div>
      </Router>
    </div>
  );
}
export default App;
