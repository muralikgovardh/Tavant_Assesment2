import React, { useState, useEffect } from "react";

import axios from "axios";

import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Container,
  Form,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Row,
  Table,
} from "reactstrap";

const ModifyEmployee = (props) => {
  const [employee, setEmployee] = useState({
    // initial values
    employeeId: "",
    firstName: "",
    lastName: "",
    email: "",
  });

  const url = "http://localhost:8080/api/employee/" + props.match.params.id; // url to connect to the backend

  useEffect(() => {
    // to render the employee details
    const GetData = async () => {
      const result = await axios.get(url);
      setEmployee(result.data);
    };

    GetData();
  }, []);
  const err1 = null;
  const UpdateEmployee = async (e) => {
    // function to update employees
    e.preventDefault();

    const data = {
      // used so as to fill the fields in the webpage when wanting to edit
      employeeId: employee.employeeId,
      firstName: employee.firstName,
      lastName: employee.lastName,
      email: employee.email,
    };
    await axios
      .put("http://localhost:8080/api/employee/" + employee.employeeId, data) // update url
      .then((result) => {
        props.history.push("/List"); // move to list
      })
      .catch((err) => {
        // if error then print it on the console
        err1 = err.response.data;
        console.log(JSON.stringify(err.response.data));
      });
  };

  const onChange = (e) => {
    // perform if any changes are done in the console
    e.persist();
    setEmployee({ ...employee, [e.target.name]: e.target.value }); // set the employee values
  };
  return (
    <div className="app flex-row align-items-center">
      <Container>
        <Row className="justify-content-center">
          <Col md="12" lg="10" xl="8">
            <Card className="mx-4">
              <CardBody className="p-4">
                <Form onSubmit={UpdateEmployee}>
                  <h1>Update Employee</h1>

                  <InputGroup className="mb-3">
                    <Input
                      type="text"
                      name="firstName"
                      id="firstName"
                      placeholder="firstname"
                      value={employee.firstName}
                      onChange={onChange}
                    />
                  </InputGroup>

                  <InputGroup className="mb-3">
                    <Input
                      type="text"
                      placeholder="lastName"
                      name="lastName"
                      id="lastName"
                      value={employee.lastName}
                      onChange={onChange}
                    />
                  </InputGroup>
                  <InputGroup className="mb-4">
                    <Input
                      type="text"
                      placeholder="email"
                      name="email"
                      id="email"
                      value={employee.email}
                      onChange={onChange}
                    />
                  </InputGroup>

                  <CardFooter className="p-4">
                    <Row>
                      <Col xs="12" sm="6">
                        <Button
                          type="submit"
                          className="btn btn-info mb-1"
                          block
                        >
                          <span>Save</span>
                        </Button>
                      </Col>

                      <Col xs="12" sm="6">
                        <Button className="btn btn-info mb-1" block>
                          <span>Cancel</span>
                        </Button>
                      </Col>
                    </Row>
                  </CardFooter>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
      {err1 ? <div>{err1}</div> : null}
    </div>
  );
};

ModifyEmployee.propTypes = {};
export default ModifyEmployee;
