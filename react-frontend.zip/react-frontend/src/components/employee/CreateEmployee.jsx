import React, { useState, useEffect } from "react";

import axios from "axios";

import {
  Button,
  Card,
  CardBody,
  CardFooter,
  Col,
  Container,
  Form,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Row,
} from "reactstrap";

const url = "http://localhost:8080/api/employee/";

const CreateEmployee = (props) => {
  const [employee, setEmployee] = useState({
    // initial values
    employeeId: "",
    firstName: "",
    lastName: "",
    email: "",
  });
  const { employeeId, firstName, lastName, email } = employee;

  const onChange = (e) => {
    // if any changes takes place on the form then change the employee values
    setEmployee({ ...employee, [e.target.name]: e.target.value });
  };

  const onSubmit = (e) => {
    // on submission check for errors , submit data and move to the list page
    e.preventDefault();

    axios
      .post(url, employee)
      .then((res) => props.history.push("/List"))
      .catch((err) => {
        console.log(JSON.stringify(err.response.data));
      });
  };

  return (
    <div className="app flex-row align-items-center">
      <Container>
        <Row className="justify-content-center">
          <Col md="12" lg="10" xl="8">
            <Card className="mx-4">
              <CardBody className="p-4">
                <Form onSubmit={onSubmit}>
                  <h1>Add Employee</h1>
                  <InputGroup className="mb-3">
                    <Input
                      type="text"
                      name="employeeId"
                      id="employeeId"
                      placeholder="Enter Employee Id"
                      value={employeeId}
                      onChange={onChange}
                    />
                  </InputGroup>
                  <InputGroup className="mb-3">
                    <Input
                      type="text"
                      name="firstName"
                      id="firstName"
                      placeholder="Enter First Name"
                      value={firstName}
                      onChange={onChange}
                    />
                  </InputGroup>
                  <InputGroup className="mb-3">
                    <Input
                      type="text"
                      name="lastName"
                      id="lastName"
                      placeholder="Enter Last Name"
                      value={lastName}
                      onChange={onChange}
                    />
                  </InputGroup>
                  <InputGroup className="mb-3">
                    <Input
                      type="text"
                      name="email"
                      id="email"
                      placeholder="Enter Email"
                      value={email}
                      onChange={onChange}
                    />
                  </InputGroup>

                  <CardFooter className="p-4">
                    <Row>
                      <Col xs="12" sm="6">
                        <Button
                          type="submit"
                          className="btn btn-info mb-1"
                          block
                        >
                          <span>Save</span>
                        </Button>
                      </Col>
                      <Col xs="12" sm="6">
                        <Button
                          type="submit"
                          className="btn btn-info mb-1"
                          block
                        >
                          <span>Cancel</span>
                        </Button>
                      </Col>
                    </Row>
                  </CardFooter>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

CreateEmployee.propTypes = {};

export default CreateEmployee;
