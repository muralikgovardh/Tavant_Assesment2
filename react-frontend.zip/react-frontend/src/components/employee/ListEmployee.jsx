import React, { useState, useEffect } from "react";

import axios from "axios";

import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Container,
  Form,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Row,
  Table,
} from "reactstrap";

const ListEmployee = (props) => {
  // function to list the employees
  const [data, setData] = useState([]);
  useEffect(() => {
    // to render the web pages
    const GetData = async () => {
      const result = await axios("http://localhost:8080/api/employee/all"); // link to the backend server
      setData(result.data);
    };
    GetData(); // get all employees from the backend server
  }, []);

  const deleteemployee = (id) => {
    // function to delete an employee
    axios
      .delete("http://localhost:8080/api/employee/delete/" + id)
      .then((result) => {
        props.history.push("/"); // if sucess move to this page
      })
      .catch((err) => {
        console.log(JSON.stringify(err.response.data)); //print errors on failure
      });
  };

  const editemployee = (id) => {
    // function to edit employee
    props.history.push({
      pathname: "/modify/" + id, // move to modify page to edit values
    });
  };

  return (
    <div className="mb-3">
      <Row>
        <Col>
          <Card>
            <CardHeader>
              <i className="fa fa-align-justify"></i>Employee List
            </CardHeader>
            <CardBody>
              <Table>
                <thead>
                  <tr>
                    <th>Employee Id</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((item, idx) => {
                    return (
                      <tr>
                        <td>{item.employeeId}</td>
                        <td>{item.fistName}</td>
                        <td>{item.lastName}</td>
                        <td>{item.email}</td>

                        <td>
                          <div class="btn-group">
                            <button
                              className="btn btn-warning"
                              onClick={() => {
                                editemployee(item.employeeId);
                              }}
                            >
                              Edit
                            </button>

                            <button
                              className="btn btn-warning"
                              onClick={() => {
                                deleteemployee(item.employeeId);
                              }}
                            >
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
};
ListEmployee.propTypes = {};

export default ListEmployee;
